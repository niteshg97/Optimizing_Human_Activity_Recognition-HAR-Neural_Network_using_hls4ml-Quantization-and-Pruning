//Numpy array shape [6]
//Min -0.165384560823
//Max 0.203014820814
//Number of zeros 0

#ifndef B6_H_
#define B6_H_

#ifndef __SYNTHESIS__
output_layer_bias_t b6[6];
#else
output_layer_bias_t b6[6] = {-0.0808882043, -0.0340079293, -0.1653845608, -0.0418453105, 0.2030148208, -0.1561084986};

#endif

#endif
