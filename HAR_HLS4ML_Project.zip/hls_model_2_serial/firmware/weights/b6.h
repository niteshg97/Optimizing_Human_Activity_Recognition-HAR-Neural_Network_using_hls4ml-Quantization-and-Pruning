//Numpy array shape [6]
//Min -0.080472797155
//Max 0.095059283078
//Number of zeros 0

#ifndef B6_H_
#define B6_H_

#ifndef __SYNTHESIS__
output_layer_bias_t b6[6];
#else
output_layer_bias_t b6[6] = {-0.0216340385, -0.0136825442, -0.0804727972, -0.0220582746, 0.0950592831, -0.0505710505};

#endif

#endif
